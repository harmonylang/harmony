Harmony is a programming language for testing and experimenting with
concurrent code.

Website: http://www.cs.cornell.edu/home/rvr/harmony/

Running harmony:

    Linux and MacOSX:
        - put harmony in your search path ($PATH)
            - see http://www.linux-migration.org/ch02s06.html
        - if you run harmony in the harmony directory, you may have to
          run "./harmony [args ...]" instead of just "harmony [args ...]"

    Windows:
        - you can't use the harmony script probably
        - try to run
            python3 harmony.py -f [args ...]
