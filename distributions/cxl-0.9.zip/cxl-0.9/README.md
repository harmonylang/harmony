CXL is a programming language for testing and experimenting with
concurrent code.

Website: http://www.cs.cornell.edu/home/rvr/cxl/

Installation: put cxl in your search path

Windows: instead of cxl, using "python3 cxl.py"
