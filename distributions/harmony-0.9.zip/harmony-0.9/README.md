Harmony is a programming language for testing and experimenting with
concurrent code.

Website: http://www.cs.cornell.edu/home/rvr/harmony/

Installation: put harmony in your search path

Windows: instead of harmony, using "python3 harmony.py"
